const Auth = {
  saveToken(token) {
    localStorage.setItem('prithvinet_token', token);
  },
  getToken() {
    return localStorage.getItem('prithvinet_token');
  },
  saveUser(user) {
    localStorage.setItem('prithvinet_user', JSON.stringify(user));
  },
  getUser() {
    const user = localStorage.getItem('prithvinet_user');
    return user ? JSON.parse(user) : null;
  },
  logout() {
    localStorage.removeItem('prithvinet_token');
    localStorage.removeItem('prithvinet_user');
    window.location.href = '/';
  },
  isAuthenticated() {
    return !!this.getToken();
  },
  async login(email, password) {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (res.ok) {
      this.saveToken(data.token);
      this.saveUser(data.user);
      this.redirectByRole(data.user.role);
    } else {
      throw new Error(data.message);
    }
  },
  redirectByRole(role) {
    switch (role) {
      case 'Super Admin': window.location.href = '/dashboard/superadmin'; break;
      case 'Regional Officer': window.location.href = '/dashboard/ro'; break;
      case 'Monitoring Team': window.location.href = '/dashboard/monitoring'; break;
      case 'Industry User': window.location.href = '/dashboard/industry'; break;
      default: window.location.href = '/';
    }
  }
};
