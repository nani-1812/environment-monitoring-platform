const Dashboard = {
    async fetchPollution() {
        const res = await fetch('/api/pollution-data');
        return await res.json();
    },
    async fetchIndustries() {
        const res = await fetch('/api/industries', {
            headers: { 'Authorization': `Bearer ${Auth.getToken()}` }
        });
        return await res.json();
    },
    async fetchInspectionHistory() {
        const res = await fetch('/api/inspections/history', {
            headers: { 'Authorization': `Bearer ${Auth.getToken()}` }
        });
        return await res.json();
    },
    async submitInspection(data) {
        const res = await fetch('/api/inspections/submit', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${Auth.getToken()}`
            },
            body: JSON.stringify(data)
        });
        return await res.json();
    },
    renderHeader(user) {
        const header = document.getElementById('dashboard-header');
        if (header) {
            header.innerHTML = `
                <div class="flex justify-between items-center px-8 py-4 bg-white/80 dark:bg-[#25282c]/80 backdrop-blur-md border-b border-[var(--border)] sticky top-0 z-50">
                    <div class="flex items-center gap-4">
                        <a href="/" class="text-xl font-black tracking-tighter text-[#2B8EDE]">PRITHVINET</a>
                        <span class="text-[10px] font-bold uppercase tracking-widest opacity-40 text-[var(--dim)]">${user.role} DASHBOARD</span>
                    </div>
                    <div class="flex items-center gap-6">
                        <div class="text-right">
                            <p class="text-sm font-bold text-[var(--text)]">${user.name || user.email}</p>
                            <p class="text-[10px] opacity-40 uppercase text-[var(--dim)]">${user.role}</p>
                        </div>
                        <button onclick="Auth.logout()" class="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-all" title="Logout">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                        </button>
                    </div>
                </div>
            `;
        }
    }
};
