import { Response } from 'express';
import db from '../db.ts';
import { AuthRequest } from '../middleware/auth.ts';

export const InspectionController = {
  assignTask: (req: AuthRequest, res: Response) => {
    const { industry_id, assigned_to_team_id } = req.body;
    try {
      const stmt = db.prepare('INSERT INTO inspections (industry_id, assigned_to_team_id) VALUES (?, ?)');
      stmt.run(industry_id, assigned_to_team_id);
      res.status(201).json({ message: 'Inspection assigned' });
    } catch (error) {
      res.status(500).json({ message: 'Internal server error' });
    }
  },

  submitReport: (req: AuthRequest, res: Response) => {
    const { inspection_id, report_text, photo_url, observations } = req.body;
    try {
      const stmt = db.prepare(`
        UPDATE inspections 
        SET report_text = ?, photo_url = ?, observations = ?, status = 'completed', completed_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `);
      stmt.run(report_text, photo_url, observations, inspection_id);
      res.json({ message: 'Report submitted' });
    } catch (error) {
      res.status(500).json({ message: 'Internal server error' });
    }
  },

  getTasks: (req: AuthRequest, res: Response) => {
    const teamId = req.user?.id;
    try {
      const tasks = db.prepare(`
        SELECT i.*, ind.company_name, ind.address 
        FROM inspections i
        JOIN industries ind ON i.industry_id = ind.id
        WHERE i.assigned_to_team_id = ?
      `).all(teamId);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: 'Internal server error' });
    }
  }
};
