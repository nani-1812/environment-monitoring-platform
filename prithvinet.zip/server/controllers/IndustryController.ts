import { Request, Response } from 'express';
import db from '../db.ts';
import { AuthRequest } from '../middleware/auth.ts';

export const IndustryController = {
  register: (req: AuthRequest, res: Response) => {
    const { company_name, owner_name, location_lat, location_lng, address, district, pin_code } = req.body;
    const userId = req.user?.id;

    try {
      const stmt = db.prepare(`
        INSERT INTO industries (user_id, company_name, owner_name, location_lat, location_lng, address, district, pin_code)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const info = stmt.run(userId, company_name, owner_name, location_lat, location_lng, address, district, pin_code);
      res.status(201).json({ message: 'Industry registered', industryId: info.lastInsertRowid });
    } catch (error) {
      res.status(500).json({ message: 'Internal server error' });
    }
  },

  getIndustries: (req: AuthRequest, res: Response) => {
    try {
      const industries = db.prepare('SELECT * FROM industries').all();
      res.json(industries);
    } catch (error) {
      res.status(500).json({ message: 'Internal server error' });
    }
  },

  getPollutionData: (req: Request, res: Response) => {
    try {
      const data = db.prepare('SELECT * FROM pollution_data').all();
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: 'Internal server error' });
    }
  }
};
