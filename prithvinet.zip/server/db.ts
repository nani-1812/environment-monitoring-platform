import Database from 'better-sqlite3';
import path from 'path';

const db = new Database('prithvinet.db');

// Initialize tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT,
    role TEXT,
    name TEXT,
    region TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS industries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    company_name TEXT,
    owner_name TEXT,
    location_lat REAL,
    location_lng REAL,
    address TEXT,
    district TEXT,
    pin_code TEXT,
    photo_url TEXT,
    registration_status TEXT DEFAULT 'pending',
    FOREIGN KEY(user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS inspections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    industry_id INTEGER,
    assigned_to_team_id INTEGER,
    status TEXT DEFAULT 'assigned',
    report_text TEXT,
    photo_url TEXT,
    observations TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME,
    FOREIGN KEY(industry_id) REFERENCES industries(id)
  );

  CREATE TABLE IF NOT EXISTS pollution_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    city TEXT,
    aqi INTEGER,
    status TEXT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

// Seed initial pollution data if empty
const rowCount = db.prepare('SELECT count(*) as count FROM pollution_data').get() as { count: number };
if (rowCount.count === 0) {
  const insert = db.prepare('INSERT INTO pollution_data (city, aqi, status) VALUES (?, ?, ?)');
  const cities = [
    ['Raipur', 145, 'Moderate'],
    ['Bhilai', 98, 'Good'],
    ['Durg', 112, 'Moderate'],
    ['Bilaspur', 156, 'Poor'],
    ['Korba', 189, 'Poor'],
    ['Raigarh', 134, 'Moderate'],
    ['Jagdalpur', 65, 'Good']
  ];
  cities.forEach(city => insert.run(...city));
}

export default db;
