import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Wind, Droplets, Volume2, Factory, ArrowRight, ShieldCheck, MapPin, ClipboardList } from 'lucide-react';

interface PollutionData {
  id: number;
  city: string;
  aqi: number;
  status: string;
}

export const HomePage: React.FC<{ onLogin: () => void }> = ({ onLogin }) => {
  const [pollutionData, setPollutionData] = useState<PollutionData[]>([]);

  useEffect(() => {
    fetch('/api/pollution-data')
      .then(res => res.json())
      .then(data => setPollutionData(data));
  }, []);

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'good': return 'text-emerald-500 bg-emerald-500/10';
      case 'moderate': return 'text-amber-500 bg-amber-500/10';
      case 'poor': return 'text-red-500 bg-red-500/10';
      default: return 'text-gray-500 bg-gray-500/10';
    }
  };

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-[32px] bg-[#2B8EDE] p-8 md:p-16 text-white">
        <div className="relative z-10 max-w-2xl space-y-6">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-bold tracking-tight leading-[0.9]"
          >
            Know Your Air.<br />Stay Informed.
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg opacity-80 max-w-md"
          >
            Live pollution monitoring across cities and industrial stations. Empowering citizens and government with real-time environmental data.
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex gap-4"
          >
            <button 
              onClick={onLogin}
              className="px-8 py-4 bg-white text-[#2B8EDE] rounded-2xl font-bold hover:scale-105 transition-transform flex items-center gap-2"
            >
              Officer Login <ArrowRight size={20} />
            </button>
          </motion.div>
        </div>
        
        {/* Abstract shapes */}
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-20 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-white rounded-full blur-[100px]" />
        </div>
      </section>

      {/* Stats Section */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { icon: Wind, label: 'Air Quality', value: '7 Stations', color: 'text-blue-500' },
          { icon: Droplets, label: 'Water Quality', value: '12 Rivers', color: 'text-cyan-500' },
          { icon: Volume2, label: 'Noise Levels', value: '24 Locations', color: 'text-indigo-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-white/5 p-6 rounded-3xl border border-black/5 dark:border-white/5 flex items-center gap-4">
            <div className={`p-4 rounded-2xl bg-gray-100 dark:bg-white/5 ${stat.color}`}>
              <stat.icon size={24} />
            </div>
            <div>
              <p className="text-sm opacity-60">{stat.label}</p>
              <p className="text-xl font-bold">{stat.value}</p>
            </div>
          </div>
        ))}
      </section>

      {/* Live Monitoring Table */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-2xl font-bold flex items-center gap-2">
            <MapPin className="text-[#2B8EDE]" /> Live City Monitoring
          </h3>
          <span className="text-xs opacity-60 uppercase tracking-widest">Updated: Just Now</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {pollutionData.map((city, i) => (
            <motion.div 
              key={city.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
              className="bg-white dark:bg-white/5 p-6 rounded-3xl border border-black/5 dark:border-white/5 space-y-4"
            >
              <div className="flex justify-between items-start">
                <h4 className="font-bold text-lg">{city.city}</h4>
                <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${getStatusColor(city.status)}`}>
                  {city.status}
                </span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold tracking-tighter">{city.aqi}</span>
                <span className="text-xs opacity-60">AQI</span>
              </div>
              <div className="w-full h-1.5 bg-gray-100 dark:bg-white/5 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-1000 ${city.aqi < 100 ? 'bg-emerald-500' : city.aqi < 150 ? 'bg-amber-500' : 'bg-red-500'}`}
                  style={{ width: `${Math.min((city.aqi / 300) * 100, 100)}%` }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-[#37393A] text-white rounded-[40px] p-8 md:p-16 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        <div className="space-y-8">
          <h3 className="text-4xl font-bold leading-tight">Government & Industry<br />Collaboration Hub</h3>
          <div className="space-y-6">
            {[
              { icon: ShieldCheck, title: 'Compliance Monitoring', desc: 'Automated tracking of industrial emission standards.' },
              { icon: Factory, title: 'Industry Portal', desc: 'Direct registration and sensor installation requests.' },
              { icon: ClipboardList, title: 'Field Inspections', desc: 'Real-time reporting from monitoring teams.' },
            ].map((item, i) => (
              <div key={i} className="flex gap-4">
                <div className="mt-1 text-[#2B8EDE]"><item.icon size={24} /></div>
                <div>
                  <h4 className="font-bold">{item.title}</h4>
                  <p className="text-sm opacity-60">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="relative aspect-square bg-[#2B8EDE]/10 rounded-full flex items-center justify-center">
          <div className="w-3/4 h-3/4 bg-[#2B8EDE] rounded-[60px] rotate-12 flex items-center justify-center">
            <ShieldCheck size={120} className="text-white -rotate-12" />
          </div>
        </div>
      </section>
    </div>
  );
};
