import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Users, Factory, ClipboardList, Send, MapPin, Search } from 'lucide-react';

export const RegionalOfficerDashboard: React.FC = () => {
  const { token, user } = useAuth();
  const [industries, setIndustries] = useState([]);
  const [monitoringTeams, setMonitoringTeams] = useState([
    { id: 101, name: 'Team Alpha (Raipur)' },
    { id: 102, name: 'Team Beta (Bhilai)' },
    { id: 103, name: 'Team Gamma (Durg)' }
  ]);
  const [selectedIndustry, setSelectedIndustry] = useState<any>(null);
  const [selectedTeam, setSelectedTeam] = useState('');

  useEffect(() => {
    fetch('/api/industries', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(res => res.json())
    .then(data => setIndustries(data));
  }, [token]);

  const handleAssign = async () => {
    if (!selectedIndustry || !selectedTeam) return;

    const res = await fetch('/api/inspections/assign', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        industry_id: selectedIndustry.id,
        assigned_to_team_id: parseInt(selectedTeam)
      })
    });

    if (res.ok) {
      alert(`Inspection assigned to ${monitoringTeams.find(t => t.id === parseInt(selectedTeam))?.name}`);
      setSelectedIndustry(null);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Regional Management</h2>
        <p className="opacity-60">Managing region: {user?.name || 'Central'}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white dark:bg-white/5 rounded-[32px] border border-black/5 dark:border-white/5 overflow-hidden">
          <div className="p-6 border-b border-black/5 dark:border-white/5 flex justify-between items-center">
            <h3 className="font-bold text-lg">Industries in Region</h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 opacity-40" size={16} />
              <input className="pl-10 pr-4 py-2 bg-gray-100 dark:bg-white/5 rounded-xl text-sm outline-none" placeholder="Search..." />
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="text-xs uppercase tracking-widest opacity-40 border-b border-black/5 dark:border-white/5">
                  <th className="px-6 py-4">Company</th>
                  <th className="px-6 py-4">District</th>
                  <th className="px-6 py-4">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-black/5 dark:divide-white/5">
                {industries.map((ind: any) => (
                  <tr key={ind.id} className="hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4 font-bold">{ind.company_name}</td>
                    <td className="px-6 py-4 text-sm">{ind.district}</td>
                    <td className="px-6 py-4">
                      <button 
                        onClick={() => setSelectedIndustry(ind)}
                        className="px-4 py-2 bg-[#2B8EDE]/10 text-[#2B8EDE] rounded-lg text-xs font-bold hover:bg-[#2B8EDE] hover:text-white transition-all"
                      >
                        Assign Inspection
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-6">
          {selectedIndustry ? (
            <div className="bg-white dark:bg-white/5 p-8 rounded-[32px] border border-[#2B8EDE] space-y-6">
              <h3 className="font-bold text-xl">Assign Task</h3>
              <div className="p-4 bg-gray-100 dark:bg-white/5 rounded-2xl">
                <p className="text-xs opacity-60 uppercase font-bold">Industry</p>
                <p className="font-bold">{selectedIndustry.company_name}</p>
                <p className="text-xs opacity-40">{selectedIndustry.address}</p>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest opacity-60">Select Monitoring Team</label>
                <select 
                  className="w-full p-4 bg-gray-100 dark:bg-white/5 rounded-2xl outline-none"
                  value={selectedTeam}
                  onChange={e => setSelectedTeam(e.target.value)}
                >
                  <option value="">Choose Team...</option>
                  {monitoringTeams.map(team => <option key={team.id} value={team.id}>{team.name}</option>)}
                </select>
              </div>

              <div className="flex gap-3">
                <button onClick={() => setSelectedIndustry(null)} className="flex-1 py-4 border border-black/10 dark:border-white/10 rounded-2xl font-bold">Cancel</button>
                <button onClick={handleAssign} className="flex-1 py-4 bg-[#2B8EDE] text-white rounded-2xl font-bold flex items-center justify-center gap-2">
                  Assign <Send size={18} />
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-[#37393A] text-white rounded-[32px] p-8 space-y-6">
              <h3 className="text-xl font-bold">Region Stats</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 bg-white/5 rounded-2xl">
                  <span className="opacity-60 text-sm">Active Industries</span>
                  <span className="font-bold">{industries.length}</span>
                </div>
                <div className="flex justify-between items-center p-4 bg-white/5 rounded-2xl">
                  <span className="opacity-60 text-sm">Pending Inspections</span>
                  <span className="font-bold">3</span>
                </div>
                <div className="flex justify-between items-center p-4 bg-white/5 rounded-2xl">
                  <span className="opacity-60 text-sm">Alerts (24h)</span>
                  <span className="font-bold text-red-400">2</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
