import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Factory, Wind, Droplets, Volume2, ShieldCheck, Clock, AlertCircle } from 'lucide-react';

export const IndustryDashboard: React.FC = () => {
  const { user } = useAuth();
  const [pollutionData, setPollutionData] = useState<any>(null);

  useEffect(() => {
    // Mocking industry-specific data
    setPollutionData({
      air: { value: 112, status: 'Moderate', trend: 'stable' },
      water: { value: 7.2, status: 'Good', trend: 'up' },
      noise: { value: 65, status: 'Good', trend: 'down' }
    });
  }, []);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Industry Dashboard</h2>
          <p className="opacity-60">Compliance and emission tracking</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-emerald-500/10 text-emerald-500 rounded-full text-xs font-bold uppercase">
          <ShieldCheck size={16} /> Certified Compliance
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { icon: Wind, label: 'Air Emission (PM 2.5)', data: pollutionData?.air, color: 'text-blue-500' },
          { icon: Droplets, label: 'Water pH Level', data: pollutionData?.water, color: 'text-cyan-500' },
          { icon: Volume2, label: 'Noise Level (dB)', data: pollutionData?.noise, color: 'text-indigo-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-white/5 p-8 rounded-[32px] border border-black/5 dark:border-white/5 space-y-4">
            <div className="flex justify-between items-start">
              <div className={`p-3 rounded-2xl bg-gray-100 dark:bg-white/5 ${stat.color}`}>
                <stat.icon size={24} />
              </div>
              <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase ${stat.data?.status === 'Good' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'}`}>
                {stat.data?.status}
              </span>
            </div>
            <div>
              <p className="text-sm opacity-60">{stat.label}</p>
              <p className="text-4xl font-bold tracking-tighter">{stat.data?.value}</p>
            </div>
            <div className="pt-4 border-t border-black/5 dark:border-white/5 flex items-center justify-between text-[10px] uppercase font-bold tracking-widest opacity-40">
              <span>Trend: {stat.data?.trend}</span>
              <span>Live Sensor</span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white dark:bg-white/5 p-8 rounded-[40px] border border-black/5 dark:border-white/5 space-y-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <Clock className="text-[#2B8EDE]" /> Inspection History
          </h3>
          <div className="space-y-4">
            {[
              { date: 'Feb 12, 2026', officer: 'RO Raipur', status: 'Passed', remarks: 'All sensors calibrated.' },
              { date: 'Jan 05, 2026', officer: 'RO Raipur', status: 'Passed', remarks: 'Standard compliance met.' },
            ].map((insp, i) => (
              <div key={i} className="p-4 bg-gray-100 dark:bg-white/5 rounded-2xl flex justify-between items-center">
                <div>
                  <p className="font-bold text-sm">{insp.date}</p>
                  <p className="text-xs opacity-60">{insp.remarks}</p>
                </div>
                <span className="text-emerald-500 text-[10px] font-bold uppercase">{insp.status}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#37393A] text-white p-8 rounded-[40px] space-y-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <AlertCircle className="text-amber-500" /> Compliance Alerts
          </h3>
          <div className="p-6 bg-white/5 rounded-3xl border border-white/5 space-y-4">
            <p className="text-sm opacity-80">Your annual environmental audit is due in 15 days. Please schedule an inspection with your Regional Officer.</p>
            <button className="w-full py-3 bg-[#2B8EDE] text-white rounded-xl text-sm font-bold">Schedule Inspection</button>
          </div>
        </div>
      </div>
    </div>
  );
};
