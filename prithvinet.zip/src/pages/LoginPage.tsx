import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { Shield, User, Users, Factory, Lock, Mail, AlertCircle } from 'lucide-react';

export const LoginPage: React.FC<{ onRegister: () => void }> = ({ onRegister }) => {
  const [role, setRole] = useState('Industry User');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();

  const roles = [
    { id: 'Super Admin', icon: Shield, label: 'Super Admin' },
    { id: 'Regional Officer', icon: User, label: 'Regional Officer' },
    { id: 'Monitoring Team', icon: Users, label: 'Monitoring Team' },
    { id: 'Industry User', icon: Factory, label: 'Industry Login' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, role }),
      });

      const data = await res.json();
      if (res.ok) {
        login(data.user, data.token);
      } else {
        setError(data.message || 'Login failed');
      }
    } catch (err) {
      setError('Connection error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto py-12">
      <div className="bg-white dark:bg-white/5 p-8 rounded-[40px] border border-black/5 dark:border-white/5 shadow-2xl shadow-black/5">
        <div className="text-center space-y-2 mb-8">
          <h2 className="text-3xl font-bold">Welcome Back</h2>
          <p className="text-sm opacity-60">Select your role and enter credentials</p>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-8">
          {roles.map((r) => (
            <button
              key={r.id}
              onClick={() => setRole(r.id)}
              className={`p-4 rounded-2xl border transition-all flex flex-col items-center gap-2 ${
                role === r.id 
                ? 'bg-[#2B8EDE] border-[#2B8EDE] text-white shadow-lg shadow-[#2B8EDE]/20' 
                : 'border-black/5 dark:border-white/5 hover:bg-black/5 dark:hover:bg-white/5'
              }`}
            >
              <r.icon size={20} />
              <span className="text-[10px] font-bold uppercase tracking-wider">{r.label}</span>
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-widest opacity-60 ml-1">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 opacity-40" size={18} />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="officer@prithvinet.gov.in"
                className="w-full pl-12 pr-4 py-4 bg-gray-100 dark:bg-white/5 rounded-2xl border-none focus:ring-2 focus:ring-[#2B8EDE] outline-none transition-all"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-widest opacity-60 ml-1">Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 opacity-40" size={18} />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-12 pr-4 py-4 bg-gray-100 dark:bg-white/5 rounded-2xl border-none focus:ring-2 focus:ring-[#2B8EDE] outline-none transition-all"
              />
            </div>
          </div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-2 p-4 bg-red-500/10 text-red-500 rounded-2xl text-sm"
            >
              <AlertCircle size={18} />
              {error}
            </motion.div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 bg-[#2B8EDE] text-white rounded-2xl font-bold hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 shadow-xl shadow-[#2B8EDE]/20"
          >
            {loading ? 'Authenticating...' : 'Sign In'}
          </button>
        </form>

        {role === 'Industry User' && (
          <div className="mt-8 pt-8 border-t border-black/5 dark:border-white/5 text-center">
            <p className="text-sm opacity-60 mb-4">New industry in Chhattisgarh?</p>
            <button onClick={onRegister} className="text-[#2B8EDE] font-bold hover:underline">Register Your Industry</button>
          </div>
        )}
      </div>
    </div>
  );
};
