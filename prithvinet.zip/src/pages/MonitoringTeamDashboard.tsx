import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { ClipboardList, Camera, CheckCircle, Clock, AlertCircle, Send } from 'lucide-react';

export const MonitoringTeamDashboard: React.FC = () => {
  const { token } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [selectedTask, setSelectedTask] = useState<any>(null);
  const [report, setReport] = useState({
    report_text: '',
    observations: '',
    photo_url: 'https://picsum.photos/seed/factory/800/600'
  });

  useEffect(() => {
    fetch('/api/inspections/tasks', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(res => res.json())
    .then(data => setTasks(data));
  }, [token]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch('/api/inspections/submit', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        inspection_id: selectedTask.id,
        ...report
      })
    });

    if (res.ok) {
      alert('Inspection report submitted successfully!');
      setSelectedTask(null);
      // Refresh tasks
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Field Operations</h2>
        <p className="opacity-60">Inspection tasks and reporting</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-4">
          <h3 className="font-bold text-lg flex items-center gap-2">
            <Clock className="text-[#2B8EDE]" size={20} /> Assigned Tasks
          </h3>
          <div className="space-y-3">
            {tasks.map((task: any) => (
              <button
                key={task.id}
                onClick={() => setSelectedTask(task)}
                className={`w-full text-left p-6 rounded-3xl border transition-all ${
                  selectedTask?.id === task.id 
                  ? 'bg-[#2B8EDE] text-white border-[#2B8EDE] shadow-lg shadow-[#2B8EDE]/20' 
                  : 'bg-white dark:bg-white/5 border-black/5 dark:border-white/5 hover:bg-black/5'
                }`}
              >
                <p className="font-bold">{task.company_name}</p>
                <p className="text-xs opacity-60 mt-1">{task.address}</p>
                <div className="flex items-center gap-2 mt-4">
                  <span className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase ${task.status === 'assigned' ? 'bg-amber-500' : 'bg-emerald-500'}`}>
                    {task.status}
                  </span>
                </div>
              </button>
            ))}
            {tasks.length === 0 && <p className="text-sm opacity-40 italic">No tasks assigned currently.</p>}
          </div>
        </div>

        <div className="lg:col-span-2">
          {selectedTask ? (
            <div className="bg-white dark:bg-white/5 rounded-[40px] border border-black/5 dark:border-white/5 overflow-hidden">
              <div className="p-8 border-b border-black/5 dark:border-white/5">
                <h3 className="text-2xl font-bold">Inspection Report</h3>
                <p className="text-sm opacity-60">Industry: {selectedTask.company_name}</p>
              </div>
              
              <form onSubmit={handleSubmit} className="p-8 space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest opacity-60">Inspection Photos</label>
                  <div className="aspect-video bg-gray-100 dark:bg-white/5 rounded-3xl overflow-hidden relative group cursor-pointer">
                    <img src={report.photo_url} alt="Inspection" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                      <Camera className="text-white" size={48} />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest opacity-60">Observations</label>
                  <textarea 
                    required
                    className="w-full p-4 bg-gray-100 dark:bg-white/5 rounded-2xl outline-none focus:ring-2 focus:ring-[#2B8EDE] h-32"
                    placeholder="Describe your findings..."
                    value={report.observations}
                    onChange={e => setReport({...report, observations: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest opacity-60">Technical Report Text</label>
                  <textarea 
                    required
                    className="w-full p-4 bg-gray-100 dark:bg-white/5 rounded-2xl outline-none focus:ring-2 focus:ring-[#2B8EDE] h-48"
                    placeholder="Enter detailed technical parameters..."
                    value={report.report_text}
                    onChange={e => setReport({...report, report_text: e.target.value})}
                  />
                </div>

                <button type="submit" className="w-full py-4 bg-[#2B8EDE] text-white rounded-2xl font-bold flex items-center justify-center gap-2">
                  Submit Final Report <Send size={20} />
                </button>
              </form>
            </div>
          ) : (
            <div className="h-full min-h-[400px] bg-white dark:bg-white/5 rounded-[40px] border border-dashed border-black/10 dark:border-white/10 flex flex-col items-center justify-center text-center p-8">
              <ClipboardList size={64} className="opacity-10 mb-4" />
              <h3 className="text-xl font-bold opacity-40">Select a task to start inspection</h3>
              <p className="text-sm opacity-30 max-w-xs">Reports must be submitted within 24 hours of field visit.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
