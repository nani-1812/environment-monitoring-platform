import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Users, Factory, AlertTriangle, FileText, Plus, Search, Map as MapIcon } from 'lucide-react';

export const SuperAdminDashboard: React.FC = () => {
  const { token } = useAuth();
  const [industries, setIndustries] = useState([]);
  const [stats, setStats] = useState({
    totalIndustries: 0,
    activeAlerts: 12,
    pendingInspections: 8,
    regionalOfficers: 5
  });

  useEffect(() => {
    fetch('/api/industries', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    .then(res => res.json())
    .then(data => {
      setIndustries(data);
      setStats(prev => ({ ...prev, totalIndustries: data.length }));
    });
  }, [token]);

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">System Overview</h2>
          <p className="opacity-60">Global monitoring and management</p>
        </div>
        <button className="px-6 py-3 bg-[#2B8EDE] text-white rounded-xl font-bold flex items-center gap-2">
          <Plus size={20} /> Add Regional Officer
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { icon: Factory, label: 'Total Industries', value: stats.totalIndustries, color: 'text-blue-500' },
          { icon: Users, label: 'Regional Officers', value: stats.regionalOfficers, color: 'text-indigo-500' },
          { icon: AlertTriangle, label: 'Active Alerts', value: stats.activeAlerts, color: 'text-red-500' },
          { icon: FileText, label: 'Pending Reports', value: stats.pendingInspections, color: 'text-amber-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-white/5 p-6 rounded-3xl border border-black/5 dark:border-white/5">
            <div className={`p-3 w-fit rounded-xl bg-gray-100 dark:bg-white/5 mb-4 ${stat.color}`}>
              <stat.icon size={24} />
            </div>
            <p className="text-sm opacity-60">{stat.label}</p>
            <p className="text-3xl font-bold tracking-tighter">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white dark:bg-white/5 rounded-[32px] border border-black/5 dark:border-white/5 overflow-hidden">
          <div className="p-6 border-b border-black/5 dark:border-white/5 flex justify-between items-center">
            <h3 className="font-bold text-lg">Industrial Units</h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 opacity-40" size={16} />
              <input className="pl-10 pr-4 py-2 bg-gray-100 dark:bg-white/5 rounded-xl text-sm outline-none" placeholder="Search industries..." />
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="text-xs uppercase tracking-widest opacity-40 border-b border-black/5 dark:border-white/5">
                  <th className="px-6 py-4">Company</th>
                  <th className="px-6 py-4">District</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-black/5 dark:divide-white/5">
                {industries.map((ind: any) => (
                  <tr key={ind.id} className="hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4 font-bold">{ind.company_name}</td>
                    <td className="px-6 py-4 text-sm">{ind.district}</td>
                    <td className="px-6 py-4">
                      <span className="px-3 py-1 bg-emerald-500/10 text-emerald-500 rounded-full text-[10px] font-bold uppercase">Active</span>
                    </td>
                    <td className="px-6 py-4">
                      <button className="text-[#2B8EDE] text-sm font-bold">View Details</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-[#37393A] text-white rounded-[32px] p-8 space-y-6">
          <h3 className="text-xl font-bold">Recent Alerts</h3>
          <div className="space-y-4">
            {[
              { city: 'Korba', type: 'SO2 Emission', time: '12m ago', level: 'High' },
              { city: 'Raipur', type: 'PM 2.5', time: '45m ago', level: 'Critical' },
              { city: 'Bhilai', type: 'Water Discharge', time: '1h ago', level: 'Warning' },
            ].map((alert, i) => (
              <div key={i} className="p-4 bg-white/5 rounded-2xl border border-white/5 flex justify-between items-center">
                <div>
                  <p className="font-bold text-sm">{alert.city} - {alert.type}</p>
                  <p className="text-[10px] opacity-40 uppercase tracking-widest">{alert.time}</p>
                </div>
                <span className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase ${alert.level === 'Critical' ? 'bg-red-500' : 'bg-amber-500'}`}>
                  {alert.level}
                </span>
              </div>
            ))}
          </div>
          <button className="w-full py-4 border border-white/10 rounded-2xl text-sm font-bold hover:bg-white/5 transition-colors">
            View All Alerts
          </button>
        </div>
      </div>
    </div>
  );
};
