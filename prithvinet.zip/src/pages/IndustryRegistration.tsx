import React, { useState } from 'react';
import { MapPicker } from '../components/MapPicker';
import { Building2, User, MapPin, Upload, CreditCard, CheckCircle } from 'lucide-react';

export const IndustryRegistration: React.FC = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    company_name: '',
    owner_name: '',
    address: '',
    district: '',
    pin_code: '',
    lat: 21.2514,
    lng: 81.6296
  });

  const districts = ['Raipur', 'Bhilai', 'Durg', 'Bilaspur', 'Korba', 'Raigarh', 'Jagdalpur'];

  const handleNext = () => setStep(step + 1);

  return (
    <div className="max-w-4xl mx-auto py-8">
      <div className="bg-white dark:bg-white/5 rounded-[40px] border border-black/5 dark:border-white/5 overflow-hidden">
        <div className="bg-[#2B8EDE] p-8 text-white">
          <h2 className="text-3xl font-bold">Industry Registration</h2>
          <p className="opacity-80">Join the PRITHVINET monitoring network</p>
          
          <div className="flex gap-4 mt-8">
            {[1, 2, 3].map((s) => (
              <div key={s} className={`h-1 flex-1 rounded-full transition-all ${step >= s ? 'bg-white' : 'bg-white/20'}`} />
            ))}
          </div>
        </div>

        <div className="p-8 md:p-12">
          {step === 1 && (
            <div className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest opacity-60 flex items-center gap-2">
                    <Building2 size={14} /> Company Name
                  </label>
                  <input 
                    className="w-full p-4 bg-gray-100 dark:bg-white/5 rounded-2xl outline-none focus:ring-2 focus:ring-[#2B8EDE]"
                    placeholder="Enter company name"
                    value={formData.company_name}
                    onChange={e => setFormData({...formData, company_name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest opacity-60 flex items-center gap-2">
                    <User size={14} /> Owner Name
                  </label>
                  <input 
                    className="w-full p-4 bg-gray-100 dark:bg-white/5 rounded-2xl outline-none focus:ring-2 focus:ring-[#2B8EDE]"
                    placeholder="Enter owner name"
                    value={formData.owner_name}
                    onChange={e => setFormData({...formData, owner_name: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest opacity-60 flex items-center gap-2">
                  <MapPin size={14} /> Factory Location
                </label>
                <MapPicker onLocationSelect={(lat, lng) => setFormData({...formData, lat, lng})} />
                <p className="text-[10px] opacity-40 italic">Click on the map to mark your factory location</p>
              </div>

              <button onClick={handleNext} className="w-full py-4 bg-[#2B8EDE] text-white rounded-2xl font-bold">Continue to Address</button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-8">
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest opacity-60">Address (House No / Street)</label>
                <textarea 
                  className="w-full p-4 bg-gray-100 dark:bg-white/5 rounded-2xl outline-none focus:ring-2 focus:ring-[#2B8EDE] h-24"
                  placeholder="Enter full address"
                  value={formData.address}
                  onChange={e => setFormData({...formData, address: e.target.value})}
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest opacity-60">District</label>
                  <select 
                    className="w-full p-4 bg-gray-100 dark:bg-white/5 rounded-2xl outline-none focus:ring-2 focus:ring-[#2B8EDE]"
                    value={formData.district}
                    onChange={e => setFormData({...formData, district: e.target.value})}
                  >
                    <option value="">Select District</option>
                    {districts.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest opacity-60">PIN Code</label>
                  <input 
                    className="w-full p-4 bg-gray-100 dark:bg-white/5 rounded-2xl outline-none focus:ring-2 focus:ring-[#2B8EDE]"
                    placeholder="492001"
                    value={formData.pin_code}
                    onChange={e => setFormData({...formData, pin_code: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest opacity-60 flex items-center gap-2">
                  <Upload size={14} /> Factory Photos
                </label>
                <div className="border-2 border-dashed border-black/10 dark:border-white/10 rounded-3xl p-12 text-center space-y-4 hover:border-[#2B8EDE] transition-colors cursor-pointer">
                  <Upload className="mx-auto opacity-40" size={48} />
                  <p className="text-sm opacity-60">Drag and drop factory photos or click to browse</p>
                </div>
              </div>

              <div className="flex gap-4">
                <button onClick={() => setStep(1)} className="flex-1 py-4 border border-black/10 dark:border-white/10 rounded-2xl font-bold">Back</button>
                <button onClick={handleNext} className="flex-1 py-4 bg-[#2B8EDE] text-white rounded-2xl font-bold">Continue to Payment</button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-8 text-center">
              <div className="w-20 h-20 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto">
                <CreditCard size={40} />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold">Registration Fee</h3>
                <p className="opacity-60">Required for environmental sensor installation & certification</p>
              </div>

              <div className="bg-gray-100 dark:bg-white/5 p-8 rounded-3xl space-y-4">
                <div className="flex justify-between items-center">
                  <span className="opacity-60">Sensor Installation</span>
                  <span className="font-bold">₹ 45,000</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="opacity-60">Annual Maintenance</span>
                  <span className="font-bold">₹ 12,000</span>
                </div>
                <div className="h-px bg-black/5 dark:bg-white/5" />
                <div className="flex justify-between items-center text-xl">
                  <span className="font-bold">Total Amount</span>
                  <span className="font-bold text-[#2B8EDE]">₹ 57,000</span>
                </div>
              </div>

              <button className="w-full py-4 bg-[#2B8EDE] text-white rounded-2xl font-bold flex items-center justify-center gap-2">
                Pay Now & Complete Registration <CheckCircle size={20} />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
