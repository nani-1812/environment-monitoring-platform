import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Layout } from './components/Layout';
import { HomePage } from './pages/HomePage';
import { LoginPage } from './pages/LoginPage';
import { IndustryRegistration } from './pages/IndustryRegistration';
import { SuperAdminDashboard } from './pages/SuperAdminDashboard';
import { RegionalOfficerDashboard } from './pages/RegionalOfficerDashboard';
import { MonitoringTeamDashboard } from './pages/MonitoringTeamDashboard';
import { IndustryDashboard } from './pages/IndustryDashboard';

const AppContent: React.FC = () => {
  const { user } = useAuth();
  const [darkMode, setDarkMode] = useState(false);
  const [view, setView] = useState<'home' | 'login' | 'register'>('home');

  // Simple routing based on auth state and explicit view state
  const renderContent = () => {
    if (user) {
      switch (user.role) {
        case 'Super Admin':
          return <SuperAdminDashboard />;
        case 'Regional Officer':
          return <RegionalOfficerDashboard />;
        case 'Monitoring Team':
          return <MonitoringTeamDashboard />;
        case 'Industry User':
          return <IndustryDashboard />;
        default:
          return <HomePage onLogin={() => setView('login')} />;
      }
    }

    switch (view) {
      case 'login':
        return <LoginPage onRegister={() => setView('register')} />;
      case 'register':
        return <IndustryRegistration />;
      default:
        return <HomePage onLogin={() => setView('login')} />;
    }
  };

  return (
    <Layout darkMode={darkMode} setDarkMode={setDarkMode}>
      {renderContent()}
    </Layout>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
