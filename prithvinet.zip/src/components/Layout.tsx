import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Sun, Moon, Globe, LogOut, Shield, Factory, ClipboardList, UserCheck } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, darkMode, setDarkMode }) => {
  const { user, logout } = useAuth();

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-[#37393A] text-white' : 'bg-[#E8EEF2] text-[#37393A]'}`}>
      <header className={`sticky top-0 z-50 border-b ${darkMode ? 'bg-[#37393A]/80 border-white/10' : 'bg-white/80 border-black/5'} backdrop-blur-md`}>
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#2B8EDE] rounded-xl flex items-center justify-center text-white font-bold text-xl">P</div>
            <div>
              <h1 className="font-bold text-lg leading-none">PRITHVINET</h1>
              <p className="text-[10px] uppercase tracking-widest opacity-60">Environmental Monitoring</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button onClick={() => setDarkMode(!darkMode)} className="p-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button className="p-2 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors flex items-center gap-2">
              <Globe size={20} />
              <span className="text-sm font-medium">EN</span>
            </button>
            
            {user && (
              <div className="flex items-center gap-4 pl-4 border-l border-black/10 dark:border-white/10">
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-bold">{user.name || user.email}</p>
                  <p className="text-[10px] opacity-60 uppercase">{user.role}</p>
                </div>
                <button onClick={logout} className="p-2 text-red-500 hover:bg-red-500/10 rounded-lg transition-colors">
                  <LogOut size={20} />
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {children}
      </main>

      <footer className={`mt-auto border-t py-8 ${darkMode ? 'border-white/10 opacity-40' : 'border-black/5 opacity-40'}`}>
        <div className="max-w-7xl mx-auto px-4 text-center text-xs">
          <p>© 2026 Chhattisgarh State Pollution Control Board. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};
